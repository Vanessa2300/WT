﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherApp
{
    public enum Colors
    {
        red,
        green,
        white,
        Magenta,
        yellow,
    }
}
