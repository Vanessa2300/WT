﻿using System;

namespace WeatherApp.Data
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
