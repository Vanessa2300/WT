﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherApp.Data
{
    public class Coords
    {
        public double lat { get; set; }
        public double lon { get; set; }
    }
}
